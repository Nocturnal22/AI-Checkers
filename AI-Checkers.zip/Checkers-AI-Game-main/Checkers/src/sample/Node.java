package sample;

import javafx.util.Pair;

import java.util.Vector;

public class Node {
    int value = -169;
    int x=-1,y=-1,x1=-1,y1=-1;
}
